import os
import json
import boto3
import requests

# Initialize environment variables
GITLAB_API_BASE_URL = os.getenv("GITLAB_API_BASE_URL", "http://localhost:8080/api/v4")
GROUP_ID = os.getenv("GROUP_ID")
GITLAB_TOKEN = os.getenv("GITLAB_SERVER_TOKEN")

HEADERS = {
    "Authorization": f"Bearer {GITLAB_TOKEN}"
}

s3_client = boto3.client('s3')


def lambda_handler(event, context):
    # Process each record in the S3 event
    for record in event['Records']:
        bucket_name = record['s3']['bucket']['name']
        object_key = record['s3']['object']['key']

        # Ensure the object is within the 'create_user/' prefix
        if object_key.startswith('create_user/'):
            # Retrieve the object from S3
            response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
            user_data = json.loads(response['Body'].read().decode('utf-8'))

            # Extract user details
            name = user_data.get("name")
            username = user_data.get("user_name")
            email = user_data.get("email")
            password = user_data.get("password")

            if not all([name, username, email, password]):
                print(f"Missing user data in {object_key}. Skipping.")
                continue

            # Create GitLab user
            user_id = create_gitlab_user(name, username, email, password)
            if user_id:
                add_user_to_group(user_id)
                create_user_repository(username)


def create_gitlab_user(name, username, email, password):
    data = {
        "name": name,
        "username": username,
        "email": email,
        "password": password,
        "skip_confirmation": True
    }
    response = requests.post(f"{GITLAB_API_BASE_URL}/users", headers=HEADERS, json=data)
    if response.status_code == 201:
        user_id = response.json()["id"]
        print(f"GitLab user created: {username} (ID: {user_id})")
        return user_id
    else:
        print(f"Failed to create GitLab user: {response.status_code}, {response.json()}")
        return None

def add_user_to_group(user_id):
    data = {
        "user_id": user_id,
        "access_level": 20  # "Reporter" role
    }
    response = requests.post(f"{GITLAB_API_BASE_URL}/groups/{GROUP_ID}/members", headers=HEADERS, json=data)
    if response.status_code == 201:
        print(f"User added to group with Reporter role (User ID: {user_id})")
    else:
        print(f"Failed to add user to group: {response.status_code}, {response.json()}")


def create_user_repository(username):
    data = {
        "name": username,
        "visibility": "private"
    }
    response = requests.post(f"{GITLAB_API_BASE_URL}/projects", headers=HEADERS, json=data)
    if response.status_code == 201:
        repo_url = response.json()["http_url_to_repo"]
        print(f"Repository created for {username}: {repo_url}")
    else:
        print(f"Failed to create repository for {username}: {response.status_code}, {response.json()}")
